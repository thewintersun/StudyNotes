### Mapillary Vistas Dataset

官方地址：https://www.mapillary.com/datasets



![](C:\Users\j00496872\AppData\Roaming\Typora\typora-user-images\1572859724050.png)

**Mapillary Vistas Dataset**

A diverse street-level imagery dataset with pixel‑accurate and instance‑specific human annotations for understanding street scenes around the world.

**Features**

- 25,000 high-resolution images
- 152 object categories
- 100 instance-specifically annotated categories
- Global reach, covering 6 continents
- Variety of weather, season, time of day, camera, and viewpoint

![1572859646016](D:\Notes\raw_images\1572859646016.png)

![1572859670149](D:\Notes\raw_images\1572859670149.png)

