CityPersons: A Diverse Dataset for Pedestrian Detection

论文地址：https://arxiv.org/abs/1702.05693

code 地址：https://bitbucket.org/shanshanzhang/citypersons/src/default/

