git config --global http.sslVerify false 

git checkout branch

`$ git clone https://gitlab.huawei.com/g00471618/CLPR`

`$ git config --global user.name "zhangshan 00123456"
`

`$ git config --global user.email "zhangshan@huawei.com"
`

